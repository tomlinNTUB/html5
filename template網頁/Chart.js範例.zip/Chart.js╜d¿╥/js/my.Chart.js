$(function(){
    var ctx = $("#myChart");

    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["幼年 0-14歲", "青壯年 15-64歲", "老年 65歲以上"],
            datasets: [{
                label: 'Taipei, 分佈百分比(%)',			
                data: [13.8, 75.98, 10.21],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.2)',                    
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(54, 162, 235, 0.2)'
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(54, 162, 235, 1)'                
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
});