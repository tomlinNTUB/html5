// 存標題列的狀態
var isOpened=true;

$(function(){
    //------------------------------------
    // 標題列動畫
    //------------------------------------	
    $('.logo').mousedown(function(){
        if(isOpened){
            //標題列動畫
            $(this).parent().stop().animate({top:-80}, {duration:500, easing:'easeOutElastic'});
			
            //logo移動
            $(this).stop().animate({top:50}, {duration:500, easing:'easeOutElastic'});
	    
            //logo旋轉						
            $(this).rotate({angle:0, animateTo:180, duration:1000});		
			
            isOpened=false;
        }else{
            //標題列動畫			
            $(this).parent().stop().animate({top:0}, {duration:100});
			
            //logo移動			
            $(this).stop().animate({top:20}, {duration:500, easing:'easeOutElastic'});			
	    
            //logo旋轉						
            $(this).rotate({angle:-180, animateTo:0, duration:1000});
				
            isOpened=true;			
        }
    })		
    //------------------------------------
    
    
    
    //------------------------------------	
    // 最新消息動畫
    //------------------------------------	
    $('.news').mouseenter(function(){
        $(this).children('h4').stop().animate({bottom:0}, {duration:500, easing:'easeOutElastic'});
    })	
	
    $('.news').mouseleave(function(){
        $(this).children('h4').stop().animate({bottom:-80}, {duration:300});
    })
    //------------------------------------
});